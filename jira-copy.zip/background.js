// background.js
// (intentionally left blank for manifest v3 requirement)
